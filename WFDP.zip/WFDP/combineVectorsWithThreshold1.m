function resultVector = combineVectorsWithThreshold1(threshold, vector1, cellVector2)
    % 使用条件索引获取满足条件的位置
    indices = vector1 >= threshold;

    % 直接基于条件索引创建结果 cell 向量
    resultVector = repmat({[]}, size(vector1)); % 初始化为全部为空数组
    resultVector(indices) = cellVector2(indices); % 只有满足条件的位置被替换

    disp(resultVector);
end
