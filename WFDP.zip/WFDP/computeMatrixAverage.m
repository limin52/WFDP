function resultMatrix = computeMatrixAverage(matrixCellArray)
    % 获取矩阵的个数和矩阵的大小
    numMatrices = numel(matrixCellArray);
    [rows, cols] = size(matrixCellArray{1}); % 假设所有矩阵大小相同
    
    % 初始化结果矩阵
    resultMatrix = zeros(rows, cols);
    
    % 对应位置相加
    for i = 1:numMatrices
        resultMatrix = resultMatrix + matrixCellArray{i};
    end
    
    % 求平均值
    resultMatrix = resultMatrix / numMatrices;
end
