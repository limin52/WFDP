function rowVec = upperTriangularToRowVector(mat)
    % 获取矩阵的大小
    n = size(mat, 1);
    
    % 初始化行向量
    rowVec = [];
    
    % 循环遍历每一行，跳过对角线元素
    for i = 1:n-1
        % 提取当前行的上三角部分
        rowPart = mat(i, i+1:end);
        % 将提取的部分添加到行向量中
        rowVec = [rowVec, rowPart];
    end
end
