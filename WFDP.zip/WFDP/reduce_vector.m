function result = reduce_vector(vectorCellArray)
    result = []; % 初始化结果向量

    while ~isempty(vectorCellArray)
        % 查找并选择最小长度的数组
        lengths = cellfun(@length, vectorCellArray);
        minLen = min(lengths);
        minLenArrays = vectorCellArray(lengths == minLen);

        % 合并所有最小长度数组的元素到一个数组中
        combinedArray = vertcat(minLenArrays{:});

        % 对整个 vectorCellArray 中的每个元素进行计数
        allElements = vertcat(vectorCellArray{:}); % 合并所有数组到一个数组中
        if minLen == 1
            selectedElement = combinedArray(1);
        else
            % 对整个 vectorCellArray 中的元素进行唯一化和计数
            [uniqueVals, ~, idx] = unique(allElements);
            freqCounts = accumarray(idx, 1);
            combinedUniqueVals = unique(combinedArray); % 最小数组中的唯一值
            combinedFreqCounts = freqCounts(ismember(uniqueVals, combinedUniqueVals)); % 最小数组唯一值的频率
            [~, maxFreqIdx] = max(combinedFreqCounts); % 找到出现次数最多的元素索引
            selectedElement = combinedUniqueVals(maxFreqIdx); % 出现次数最多的值
        end

        % 将选中的元素加入结果向量
        result(end+1) = selectedElement;

        % 从向量中删除包含已选元素的数组
        vectorCellArray = vectorCellArray(~cellfun(@(x) any(x == selectedElement), vectorCellArray));
    end
end
