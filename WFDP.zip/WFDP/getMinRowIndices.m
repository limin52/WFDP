function minRowIndices = getMinRowIndices(matrix)
    % 初始化结果单元格数组
    minRowIndices = cell(1, size(matrix, 2));

    % 遍历每列，找到所有最小值对应的行号
    for col = 1:size(matrix, 2)
        % 找到当前列的最小值
        min_val = min(matrix(:, col));
        
        % 找到所有等于最小值的行号
        min_indices = find(matrix(:, col) == min_val);
        
        % 存储到结果单元格数组中
        minRowIndices{col} = min_indices;
    end
end
