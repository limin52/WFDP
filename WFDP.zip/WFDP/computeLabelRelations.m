function relationMatrices = computeLabelRelations(data)
    % data: 一个矩阵，每行是一个对象，每列是一个标签
    
    % 初始化输出的单独矩阵
    [numObjects, numLabels] = size(data);
    relationMatrices = cell(1, numLabels); % 每个标签一个矩阵

    for i = 1:numLabels
        % 对于每个标签，计算关系矩阵
        labelData = data(:, i);
        relationMatrix = zeros(numObjects, numObjects);
        
        for j = 1:numObjects
            for k = (j + 1):numObjects % 只计算上三角
                if isnan(labelData(j)) || isnan(labelData(k)) || labelData(j) ~= labelData(k)
                    relationMatrix(j, k) = 1;
                end
                % 对角线元素保持为0（在初始化时已设为0）
            end
        end
        
        % 填充下三角部分（对称矩阵）
        %relationMatrix = relationMatrix + triu(relationMatrix, 1)';

        % 存储这个标签的关系矩阵
        relationMatrices{i} = relationMatrix;
    end
end
