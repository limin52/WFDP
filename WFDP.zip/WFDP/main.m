% Copyright (c) [2024] [代建华(Daijianhua)] and [李敏(Limin)]
% All rights reserved.

tic;
clear; clc; close all;

load('data\Flags.mat');

% train_data = [0.2  0.3  0.2  0.2
%               0.3  0.2  0.1  0.3
%               0.4  0    0    0.4
%               0.1  0.1  0    0.1
%               0.4  0.1  0.3  0];
% train_label = [1 0 1 
%                0 0 0 
%                1 1 1 
%                0 1 1
%                1 0 0];

missingRatio = 0.2;
matrixWithMissing = introduceMissingValues(train_label, missingRatio);

simMatrices = computeAttributeSimilarity(train_data);

minsimMatrices = getMinRowIndices(simMatrices);

labelRelation = computeLabelRelations(matrixWithMissing);

resultMatrix = computeMatrixAverage(labelRelation);

rowVec = upperTriangularToRowVector(resultMatrix);

thresholds = [0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9]; 
numThresholds = numel(thresholds);

red = cell(1, numThresholds);  
results = cell(numThresholds, 5); 

for i = 1:numThresholds
    threshold = thresholds(i);
    
    resultVector = combineVectorsWithThreshold1(threshold, rowVec, minsimMatrices);
    filteredCellArray = resultVector(~cellfun(@isempty, resultVector));
    
    red{i} = reduce_vector(filteredCellArray);
    
    [HL, RL, OE, C, AP] = mlknn(train_data(:,red{i}), train_label', test_data(:,red{i}), test_label');
    results{i, 1} = HL;
    results{i, 2} = RL;
    results{i, 3} = OE;
    results{i, 4} = C;
    results{i, 5} = AP;

end

[HL_orig,RL_orig,OE_orig,C_orig,AP_orig]=mlknn(train_data,train_label',test_data,test_label');
Orig_Results = [HL_orig,RL_orig,OE_orig,C_orig,AP_orig]

results
red


toc;






















