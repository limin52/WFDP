% Copyright (c) [2024] [代建华(Daijianhua)] and [李敏(Limin)]
% All rights reserved.

tic;
clear; clc; close all;

load('data\Flags.mat');

missingRatio = 0.2;
matrixWithMissing = introduceMissingValues(train_label, missingRatio);

simMatrices = computeAttributeSimilarity(train_data);

minsimMatrices = getMinRowIndices(simMatrices);

labelRelation = computeLabelRelations(matrixWithMissing);

resultMatrix = computeMatrixAverage(labelRelation);

rowVec = upperTriangularToRowVector(resultMatrix);

thresholds = [0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9]; 
numThresholds = numel(thresholds);

red = cell(1, numThresholds);  
results = cell(numThresholds, 5); 

for i = 1:numThresholds
    threshold = thresholds(i);
    
    resultVector = combineVectorsWithThreshold1(threshold, rowVec, minsimMatrices);
    filteredCellArray = resultVector(~cellfun(@isempty, resultVector));
    
    red{i} = reduce_vector(filteredCellArray);

end

toc;






















