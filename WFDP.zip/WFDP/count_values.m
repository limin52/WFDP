function result = count_values(vectorCellArray)
    % 初始化结果向量
    result = [];
    
    % 当输入向量中还有元素时，继续循环
    while ~isempty(vectorCellArray)
        % 使用容器映射来统计各个值的出现次数
        counts = containers.Map('KeyType', 'double', 'ValueType', 'int32');%dictionary
        for i = 1:length(vectorCellArray)
            array = vectorCellArray{i};
            for j = 1:length(array)
                value = array(j);
                if counts.isKey(value)
                    counts(value) = counts(value) + 1;
                else
                    counts(value) = 1;
                end
            end
        end
        
        % 如果统计结果为空，跳出循环
        if isempty(counts)
            break;
        end
        
        % 找到出现次数最多的值
        maxCount = 0;
        mostFrequent = NaN;
        keys = counts.keys;
        for k = 1:length(keys)
            key = keys{k};
            count = counts(key);
            if count > maxCount
                maxCount = count;
                mostFrequent = key;
            end
        end
        
        % 将出现次数最多的值加入结果向量
        result(end+1) = mostFrequent;
        
        % 删除包含最频繁出现值的数组
        vectorCellArray = vectorCellArray(~cellfun(@(x) any(x == mostFrequent), vectorCellArray));
    end
end
