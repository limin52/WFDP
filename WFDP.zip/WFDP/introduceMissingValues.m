function matrixWithMissing = introduceMissingValues(labelMatrix, missingRatio)
    %rng(0);  % 设置种子为0
    % 接下来是你的代码，比如随机采样、随机缺失数据生成等

    % 计算矩阵大小
    [rows, cols] = size(labelMatrix);

    % 计算总元素数量
    totalElements = rows * cols;

    % 计算需要引入的缺失值数量
    numMissing = round(totalElements * missingRatio);

    % 创建一个与原始矩阵大小相同的索引矩阵
    indices = randperm(totalElements, numMissing);

    % 复制原始矩阵
    matrixWithMissing = labelMatrix;

    % 将选定的元素设置为NaN
    matrixWithMissing(indices) = NaN;
end
